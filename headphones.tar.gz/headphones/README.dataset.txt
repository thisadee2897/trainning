# headphones > 2025-12-18 12:35am
https://universe.roboflow.com/aihat/headphones-moskk

Provided by a Roboflow user
License: CC BY 4.0

